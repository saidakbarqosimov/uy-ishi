SELECT * FROM Meva 
ORDER BY LENGTH(nomi), narxi DESC;
